﻿using System;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace TcpChating
{
    public partial class MainForm : Form
    {
		private IPAddress m_clientIp = null;
		private Socket m_socket = null;
		private Thread m_thread;

		private NetworkStream m_ns = null;
		private StreamReader m_reader = null;
		private StreamWriter m_writer = null;
		string message;

		public int cut = 0;

		public MainForm()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

		private void MainForm_Load(object sender, EventArgs e)
		{
			StartServer();
		}

		public void StartServer()
		{
			try
			{
				WriteMessage("서버실행");
				m_thread = new Thread(new ThreadStart(ServerProc));
				m_thread.IsBackground = true;
				m_thread.Start();
			}

			catch { WriteMessage("서버실패"); }
		}

		private void ServerProc()
		{
			try
			{
				LiRe();
			}
			catch (Exception e) { }
		}

		private void LiRe()
		{
			TcpListener tcpListener = null;
			Socket clientSocket = null;

			try
			{
				tcpListener = new TcpListener(80);
				tcpListener.Start();
				clientSocket = tcpListener.AcceptSocket();
				WriteMessage("클라이언트가 접속됬습니다.");

				if (clientSocket.Connected == true && clientSocket != null)
				{
					m_socket = clientSocket;
					m_clientIp = ((IPEndPoint)m_socket.RemoteEndPoint).Address;

					m_ns = new NetworkStream(m_socket);
					m_reader = new StreamReader(m_ns);
					m_writer = new StreamWriter(m_ns);
				}
			}

			finally
			{
				try
				{
					if (!m_socket.Connected)
						MessageBox.Show("소켓 연결부터 확인하세요.");

					else
					{
						message = m_reader.ReadLine();
						WriteMessage("(상대)" + "\t" + message);
						
						m_writer.WriteLine("OK");
						m_writer.Flush();
						cut = 1;
					}	
				}

				finally
				{
					clientSocket.Close();
					tcpListener.Stop();

					m_writer.Close();
					m_reader.Close();
					m_ns.Close();

					m_socket.Close();
					m_socket.Shutdown(SocketShutdown.Both);
				}
			}
		}
       
        private void WriteMessage(string message)
        {
            txtOut.AppendText(message + "\r\n");
            txtOut.ScrollToCaret();
        }

		private void timer1_Tick(object sender, EventArgs e)
		{
			if (cut == 1)
			{
				cut = 0;
				StartServer();
			}

			else { }
		}
    }
}
